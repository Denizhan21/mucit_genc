<?php

namespace App\Http\Controllers;

use App\Club_contact;
use Illuminate\Http\Request;

class ClubContactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Club_contact  $club_contact
     * @return \Illuminate\Http\Response
     */
    public function show(Club_contact $club_contact)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Club_contact  $club_contact
     * @return \Illuminate\Http\Response
     */
    public function edit(Club_contact $club_contact)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Club_contact  $club_contact
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Club_contact $club_contact)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Club_contact  $club_contact
     * @return \Illuminate\Http\Response
     */
    public function destroy(Club_contact $club_contact)
    {
        //
    }
}
