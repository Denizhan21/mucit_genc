<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Club_contact extends Model
{
    protected $table = 'club_contacts';
    protected $guarded = [];
}
