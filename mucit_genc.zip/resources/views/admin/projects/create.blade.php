@extends('admin.template')

@section('icerik')

@endsection

@section('css')

@endsection

@section('js')

@endsection
