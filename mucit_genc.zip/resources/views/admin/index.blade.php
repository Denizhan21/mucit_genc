@extends('admin.template')

@section('icerik')

{{--@foreach(\Illuminate\Support\Facades\Auth::user()->project as $projects)

    {{$projects->name}}

@endforeach--}}

   {{-- @foreach($clubs->project as $club)

        {{$club->name}}
        <br>
    @endforeach

    {{$clubs->name}}--}}

{{--{{$clubs}}--}}

{{--    @foreach($projects as $project)--}}

{{--        {{$project->club->name}}--}}
{{--        <br>--}}
{{--    @endforeach--}}


@endsection

@section('css')

@endsection

@section('js')

@endsection
