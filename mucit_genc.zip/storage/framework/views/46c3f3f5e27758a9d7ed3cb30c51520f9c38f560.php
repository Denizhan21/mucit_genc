<?php $__env->startSection('content'); ?>
    <section class="section blog-grid">
        <div class="container">
            <div class="section-heading flex-heading">
                <div class="row">
                    <div class="col-lg-5">
                        <h2 class="heading-title">Duyurular</h2>
                    </div>
                    <div class="col-lg-7">

                    </div>
                </div>
            </div>
    <div class="row">
        <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="blog-box">
                    <div class="blog-img">
                        <a href="/activities/<?php echo e($activities->id); ?>">
                            <img style="width: 510px;height: 340px;" src="/<?php echo e($activities->photo); ?>" alt="Blog">
                        </a>
                        <div class="blog-date"><i class="icofont-calendar"></i>  <?php
                                setlocale(LC_TIME, "turkish");
                                setlocale(LC_ALL,'turkish');
                                echo iconv('latin5','utf-8',strftime('%d %B %Y %A',strtotime($activities->created_at)));
                            ?></div>2
                    </div>
                    <div class="blog-content">
                        <h3 class="blog-title"><a href="single-blog.html"><?php echo e($activities->title); ?> </a> (<?php echo e($activities->type); ?>)</h3>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/activity_view.blade.php ENDPATH**/ ?>