<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container">
            <div class="block-box user-single-blog">
                <div class="blog-content-wrap">
                    <div class="blog-comment-form">
                        <h3 class="item-title">Kulüp Öğretmeni İle İletişime Geçin</h3>
                        <?php echo Form::open(['route'=>['club_contact_store'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>


                        <div class="row gutters-20">


                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                                    <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                    <input type="hidden" name="club_id" value="<?php echo e($clubs->id); ?>">
                                    <input type="hidden" name="status" value="0">

                                <?php endif; ?>
                            <?php endif; ?>








                                <div class="col-lg-12 form-group" >
                                    <label>Konu:</label>
                                    <input id="name" type="text" class="form-control"  name="subject"  >
                                </div>




                            <div class="col-lg-12 form-group">
                                <textarea name="content" class="form-control textarea" placeholder="Mesajınızın detayını yazınız . . ." cols="30" rows="7"></textarea>
                            </div>


                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                                    <div class="col-lg-12 form-group">
                                        <button id="gameStart" class="submit-btn" type="submit">Gönder</button>
                                    </div>

                                <?php else: ?>

                                    <div class="alert alert-info">
                                        Projenizi göndermek için lütfen giriş yapınız. Giriş yapmak için


                                        <a href="<?php echo e(route('login')); ?>" class="alert-link">
                                            tıklayınız.
                                        </a>


                                    </div>


                                <?php endif; ?>
                            <?php endif; ?>



                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/club_contact.blade.php ENDPATH**/ ?>