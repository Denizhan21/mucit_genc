<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <!--=====================================-->
        <!--=        Newsfeed  Area Start       =-->
        <!--=====================================-->
        <div class="container">
            <div class="block-box user-single-blog">
                <div class="blog-thumbnail">
                    <img src="/<?php echo e($activity->photo); ?>" alt="Blog">
                </div>
                <div class="blog-content-wrap">
                    <div class="blog-entry-header">

                        <h2 class="entry-title"><?php echo e($activity->title); ?></h2>
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <ul class="entry-meta">
                                    <li><i class="icofont-calendar"></i>  <?php
                                            setlocale(LC_TIME, "turkish");
                                            setlocale(LC_ALL,'turkish');
                                            echo iconv('latin5','utf-8',strftime('%d %B %Y %A',strtotime($activity->created_at)));
                                        ?></li>
                                </ul>
                            </div>

                        </div>
                    </div>
                    <div class="blog-content">
                        <?php echo $activity->content; ?>

                    </div>


                </div>
            </div>

        </div>




    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/activity_details.blade.php ENDPATH**/ ?>