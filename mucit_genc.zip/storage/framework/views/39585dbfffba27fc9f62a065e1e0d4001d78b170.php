<?php $__env->startSection('icerik'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="box">

                <div class="box-header with-border">
                    <h4 class="box-title">Kulüp Öğrencileri</h4>
                    <div class="pull-right">

                        <button type="button" class="btn btn-primary">Öğrenci Ekle</button>

                    </div>
                </div>
                <div class="box-body no-padding">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tr>
                                <th>Ad Soyad</th>
                                <th>Okul</th>
                                <th>Sınıf</th>
                                <th>Şube</th>
                                <th>Projeleri</th>
                                <th>Ödevleri</th>
                                <th>Kulüpten Çıkar</th>
                            </tr>
                            <?php $__currentLoopData = $club_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$club_students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($club_students->student->name); ?></td>
                                    <td><?php echo e($club_students->student->school); ?></td>
                                    <td><?php echo e($club_students->student->class); ?></td>
                                    <td><?php echo e($club_students->student->branch); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <?php echo Form::open(['method'=>'DELETE','action'=>['ClubController@destroy',$club_students->id],'style'=>'display:inline']); ?>

                                        <button onclick="return confirm('Emin misin?')" class="btn btn-xs btn-danger"><i class="fa fa-minus"></i></button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <ul class="pagination pagination-sm pull-right">
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        <?php if(session('alert')): ?>
        swal({
            title:"Başarılı",
            text:"Kulüp Silindi",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('no')): ?>
        swal({
            title:"Başarısız",
            text:"Kulüp Silinemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/admin/club_user/index.blade.php ENDPATH**/ ?>