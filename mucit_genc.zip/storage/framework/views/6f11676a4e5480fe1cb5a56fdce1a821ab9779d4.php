<?php $__env->startSection('content'); ?>


    <div class="page-content">


        <div class="container">

            <form action="" method="get">
            <div class="block-box product-filter">
                <label>Filtrele:</label>

                <div class="select-box">
                    <input class="form-control" type="text" name="name" value="<?php echo e($name); ?>" placeholder="Proje Adı">
                </div>


                <div class="select-box">
                    <select class="form-control" name="order_club">
                        <option value="">Kulüp Seç</option>
                        <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($club->id); ?>" <?php echo e($order_club==$club->id?'selected':''); ?>><?php echo e($club->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                   
                    <select class="form-control" name="order_type">
                        <option value="">Sıralama</option>
                        <option value="desc" <?php echo e($order_type=='desc'?'selected':''); ?>>Sondan Başa</option>
                        <option value="asc" <?php echo e($order_type=='asc'?'selected':''); ?>>Baştan Sona</option>
                    </select>

                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                    <select class="form-control" name="user_id">
                        <option value="">Projeyi GÖnderren</option>
                        <?php $__currentLoopData = $project_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($users->id); ?>" <?php echo e($user_id==$users->id?'selected':''); ?>><?php echo e($users->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="filter-btn">
                    <button type="submit" class="btn btn-sm btn-primary"><i class="icofont-search-2"></i> Getir</button>
                    <a href="<?php echo e(route('project_view')); ?>" class="btn btn-xs btn-danger"><i class="icofont-magic"></i> Temizle</a>
                </div>

            </div>
            </form>









            <div class="row gutters-20">

                <?php $__currentLoopData = $request_forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="block-box user-blog">
                            <div class="blog-img">
                                <a href="/projects/<?php echo e($projects->id); ?>">

                                    <?php if($projects->type == 'Fotoğraf'): ?>
                                        <?php $__currentLoopData = json_decode($projects->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php echo e($key==0?'active':''); ?>">
                                                <img style="width: 376px;height: 250px" src="/<?php echo e($image); ?>" alt="Groups">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <img style="width: 376px;height: 250px" src="/<?php echo e($projects->photo); ?>" alt="Groups">
                                    <?php endif; ?>



                                </a>
                            </div>

                            <div class="blog-content">
                                <div class="blog-category">
                                    <a href="/clubs/<?php echo e($projects->club->id); ?>"><?php echo e($projects->club->name); ?></a>

                                </div>
                                <h3 class="blog-title"><a href="/projects/<?php echo e($projects->id); ?>"><?php echo e($projects->name); ?></a></h3>
                                <div class="blog-date"><i class="icofont-calendar"></i>
                                    <?php
                                        setlocale(LC_TIME, "turkish");
                                        setlocale(LC_ALL,'turkish');
                                        echo iconv('latin5','utf-8',strftime('%d %B %Y %A',strtotime($projects->created_at)));
                                    ?>
                                </div>
                                <p><?php echo substr($projects->description,0,20); ?>...</p>
                            </div>
                            <div class="blog-meta">
                                <ul>
                                    <li class="blog-reaction">
                                        <div class="reaction-icon">
                                            <?php
                                            $reaction_1 = count(\App\Rating::where('rateable_id','=',$projects->id)->where('rateable_type','=',1)->get())
                                            ?>
                                            <?php if(!empty($reaction_1)): ?>
                                            <img src="/homepage/media/figure/like.svg" alt="Like">
                                            <?php endif; ?>
                                            <?php
                                            $reaction_2 = count(\App\Rating::where('rateable_id','=',$projects->id)->where('rateable_type','=',2)->get())
                                            ?>
                                            <?php if(!empty($reaction_2)): ?>
                                            <img src="/homepage/media/figure/celebrate.svg" alt="Like">
                                                <?php endif; ?>
                                                <?php
                                            $reaction_3 = count(\App\Rating::where('rateable_id','=',$projects->id)->where('rateable_type','=',3)->get())
                                                ?>
                                                <?php if(!empty($reaction_3)): ?>
                                            <img src="/homepage/media/figure/support.svg" alt="Like">
                                                <?php endif; ?>
                                                <?php
                                            $reaction_4 = count(\App\Rating::where('rateable_id','=',$projects->id)->where('rateable_type','=',4)->get())
                                                ?>
                                                <?php if(!empty($reaction_4)): ?>
                                            <img src="/homepage/media/figure/love.svg" alt="Like">
                                                <?php endif; ?>
                                                <?php
                                            $reaction_5 = count(\App\Rating::where('rateable_id','=',$projects->id)->where('rateable_type','=',5)->get())
                                                ?>
                                                <?php if(!empty($reaction_5)): ?>
                                            <img src="/homepage/media/figure/insightful.svg" alt="Like">
                                                <?php endif; ?>
                                                <?php
                                            $reaction_6 = count(\App\Rating::where('rateable_id','=',$projects->id)->where('rateable_type','=',6)->get())
                                                ?>
                                                <?php if(!empty($reaction_6)): ?>
                                            <img src="/homepage/media/figure/curious.svg" alt="Like">
                                                <?php endif; ?>

                                        </div>
                                        <div class="meta-text">
                                            <?php echo e(count($rating = \App\Rating::where('rateable_id','=',$projects->id)->get())); ?>

                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="block-box post-view">
                            <div class="post-footer">
                                <ul>
                                    <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <li class="post-react">
                                                <a href="#"><i class="icofont-thumbs-up"></i>Emoji Bırak!</a>
                                                <ul class="react-list">
                                                    <?php
                                                        $login = \Illuminate\Support\Facades\Auth::id();

                                                    $rating_login = \App\Rating::where('rateable_id','=',$projects->id)->where('user_id','=',$login)->first();
                                                    ?>
                                                    <?php if(!empty($rating_login)): ?>
                                                        <?php echo Form::model($rating_login,['route'=>['like_send_update',$rating_login->id],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>

                                                        <li><label class="like-button" for="<?php echo e($key+7); ?>"><input id="<?php echo e($key+7); ?>" type="radio" name="rateable_type" value="1" <?php echo e($rating_login->rateable_type==1?'checked':''); ?>><img src="/homepage/media/figure/like.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+14); ?>"><input id="<?php echo e($key+14); ?>" type="radio" name="rateable_type" value="2" <?php echo e($rating_login->rateable_type==2?'checked':''); ?>><img src="/homepage/media/figure/celebrate.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+21); ?>"><input id="<?php echo e($key+21); ?>" type="radio" name="rateable_type" value="3" <?php echo e($rating_login->rateable_type==3?'checked':''); ?>><img src="/homepage/media/figure/support.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+28); ?>"><input id="<?php echo e($key+28); ?>" type="radio" name="rateable_type" value="4" <?php echo e($rating_login->rateable_type==4?'checked':''); ?>><img src="/homepage/media/figure/love.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+35); ?>"><input id="<?php echo e($key+35); ?>" type="radio" name="rateable_type" value="5" <?php echo e($rating_login->rateable_type==5?'checked':''); ?>><img src="/homepage/media/figure/insightful.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+42); ?>"><input id="<?php echo e($key+42); ?>" type="radio" name="rateable_type" value="6" <?php echo e($rating_login->rateable_type==6?'checked':''); ?>><img src="/homepage/media/figure/curious.svg" alt="Like"></label></li>
                                                        <li><button class="btn btn-white" type="submit">Gönder</button></li>
                                                        <?php echo Form::close(); ?>

                                                    <?php else: ?>
                                                        <?php echo Form::open(['route'=>['like_send'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>

                                                        <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                                        <input type="hidden" name="rateable_id" value="<?php echo e($projects->id); ?>">
                                                        <input type="hidden" name="rating" value="1">
                                                        <li><label class="like-button" for="<?php echo e($key+7); ?>"><input id="<?php echo e($key+7); ?>" type="radio" name="rateable_type" value="1" ><img src="/homepage/media/figure/like.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+14); ?>"><input id="<?php echo e($key+14); ?>" type="radio" name="rateable_type" value="2" ><img src="/homepage/media/figure/celebrate.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+21); ?>"><input id="<?php echo e($key+21); ?>" type="radio" name="rateable_type" value="3" ><img src="/homepage/media/figure/support.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+28); ?>"><input id="<?php echo e($key+28); ?>" type="radio" name="rateable_type" value="4" ><img src="/homepage/media/figure/love.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+35); ?>"><input id="<?php echo e($key+35); ?>" type="radio" name="rateable_type" value="5" ><img src="/homepage/media/figure/insightful.svg" alt="Like"></label></li>
                                                        <li><label class="like-button" for="<?php echo e($key+42); ?>"><input id="<?php echo e($key+42); ?>" type="radio" name="rateable_type" value="6" ><img src="/homepage/media/figure/curious.svg" alt="Like"></label></li>
                                                        <li><button class="btn btn-white" type="submit">Gönder</button></li>
                                                        <?php echo Form::close(); ?>

                                                    <?php endif; ?>


                                                </ul>
                                            </li>
                                <?php endif; ?>
                                <?php endif; ?>
                                </ul>
                            </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/project_view.blade.php ENDPATH**/ ?>