<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar">

        <!-- sidebar menu-->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="user-profile treeview">
                <a href="index.html">
                    <img src="/admin/images/avatar.jpg" alt="user">
                    <span><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="javascript:void()"><i class="fa fa-user mr-5"></i>My Profile </a></li>
                    <li><a href="javascript:void()"><i class="fa fa-money mr-5"></i>My Balance</a></li>
                    <li><a href="javascript:void()"><i class="fa fa-envelope-open mr-5"></i>Inbox</a></li>
                    <li><a href="javascript:void()"><i class="fa fa-cog mr-5"></i>Account Setting</a></li>
                    <li><a href="javascript:void()"><i class="fa fa-power-off mr-5"></i>Logout</a></li>
                </ul>
            </li>
            <li class="header nav-small-cap">PERSONAL</li>
            <li class="active">
                <a href="<?php echo e(route('admin.index')); ?>">
                    <i class="fa fa-home"></i> <span>Anasayfa</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-user"></i>
                    <span>Kullanıcı İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('users.index','authority=admin')); ?>"><i class="fa fa-circle-thin"></i>Yöneticiler</a></li>
                    <li><a href="<?php echo e(route('users.index','authority=teacher')); ?>"><i class="fa fa-circle-thin"></i>Öğretmenler</a></li>
                    <li><a href="<?php echo e(route('users.index','authority=student')); ?>"><i class="fa fa-circle-thin"></i>Öğrenciler</a></li>
                    <li><a href="<?php echo e(route('users.create')); ?>"><i class="fa fa-circle-thin"></i>Kullanıcı Ekle</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-building-o"></i>
                    <span>Proje İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('projects.all')); ?>"><i class="fa fa-circle-thin"></i>Projeler</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-building-o"></i>
                    <span>Okul İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('schools.index')); ?>"><i class="fa fa-circle-thin"></i>Okullar</a></li>
                    <li><a href="<?php echo e(route('schools.create')); ?>"><i class="fa fa-circle-thin"></i>Okul Ekle</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cc-diners-club "></i>
                    <span>Kulüp İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('clubs.index')); ?>"><i class="fa fa-circle-thin"></i>Kulüpler</a></li>
                    <li><a href="<?php echo e(route('clubs.create')); ?>"><i class="fa fa-circle-thin"></i>Kulüp Ekle</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-newspaper-o"></i>
                    <span>Duyuru İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('activities.index')); ?>"><i class="fa fa-circle-thin"></i>Duyurular</a></li>
                    <li><a href="<?php echo e(route('activities.create')); ?>"><i class="fa fa-circle-thin"></i>Duyuru Ekle</a></li>
                </ul>
            </li>


            <li class="treeview">
                <a href="#">
                    <i class="fa fa-newspaper-o"></i>
                    <span>Gündem İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('news.index')); ?>"><i class="fa fa-circle-thin"></i>Gündemler</a></li>
                    <li><a href="<?php echo e(route('news.create')); ?>"><i class="fa fa-circle-thin"></i>Gündem Ekle</a></li>
                </ul>
            </li>


            <li class="treeview">
                <a href="#">
                    <i class="fa fa-newspaper-o"></i>
                    <span>Yorum İşlemleri</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(route('comments.index')); ?>"><i class="fa fa-circle-thin"></i>Yorumlar</a></li>
                </ul>
            </li>

            <li class="">
                <a href="http://127.0.0.1:8000/laravel-filemanager">
                    <i class="fa fa-file-archive-o"></i> <span>Dosya Yönetimi</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
            </li>

            <li class="">
                <a href="<?php echo e(route('logs')); ?>">
                    <i class="fa fa-calendar"></i> <span>Log Kayıtları</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
                </a>
            </li>

        </ul>
    </section>
</aside>
<?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>