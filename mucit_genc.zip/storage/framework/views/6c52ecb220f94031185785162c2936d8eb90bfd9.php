<?php $__env->startSection('icerik'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="box">

                <div class="box-header with-border">
                    <h4 class="box-title">Kulüpler</h4>
                </div>
                <div class="box-body no-padding">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tr>
                                <th>Kulüp İsmi</th>
                                <?php if(\Illuminate\Support\Facades\Auth::user()->authority=='admin'): ?>
                                <th>Görevli Öğretmen</th>
                                <?php endif; ?>
                                <th>Kayıtlı Okul</th>
                                <th>Kulüp Katılım Linki</th>
                                <th>Kayıtlı Öğrenciler</th>
                                <th>Gönderilen Projeler</th>
                                <th>Düzenle</th>
                                <th>Sil</th>
                            </tr>
                            <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$clubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\Illuminate\Support\Facades\Auth::user()->authority=='admin' OR (\Illuminate\Support\Facades\Auth::user()->authority=='teacher' and $clubs->teacher == \Illuminate\Support\Facades\Auth::user()->name)): ?>
                                <tr>
                                    <td><?php echo e($clubs->name); ?></td>
                                    <?php if(\Illuminate\Support\Facades\Auth::user()->authority=='admin'): ?>
                                    <td><?php echo e($clubs->teachers->name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($clubs->schools->name); ?></td>
                                    <td><a href="<?php echo e(route('club_join',$clubs->code)); ?>"><?php echo e(route('club_join',$clubs->code)); ?></a></td>
                                    <td><a class="" href="<?php echo e(route('club_user.index','club='.$clubs->id)); ?>"><span class="label label-success">Git</span></a></td>
                                    <td><a class="" href="<?php echo e(route('projects.index','club='.$clubs->id)); ?>"><span class="label label-success">Git</span></a></td>
                                    <td><a class="btn btn-xs btn-warning" href="<?php echo e(route('clubs.edit',$clubs->id)); ?>"><i class="fa fa-pencil-square-o"></i></a></td>
                                    <td>
                                        <?php echo Form::open(['method'=>'DELETE','action'=>['ClubController@destroy',$clubs->id],'style'=>'display:inline']); ?>

                                        <button onclick="return confirm('Emin misin?')" class="btn btn-xs btn-danger"><i class="fa fa-minus"></i></button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <ul class="pagination pagination-sm pull-right">
                            <?php echo e($request_forms->appends(request()->query())->links()); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        <?php if(session('alert')): ?>
        swal({
            title:"Başarılı",
            text:"Kulüp Silindi",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('no')): ?>
        swal({
            title:"Başarısız",
            text:"Kulüp Silinemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/admin/clubs/index.blade.php ENDPATH**/ ?>