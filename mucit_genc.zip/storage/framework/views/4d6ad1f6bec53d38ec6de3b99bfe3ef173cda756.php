<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container">
            <div class="block-box user-single-blog">
                <div class="blog-content-wrap">
                    <div class="blog-comment-form">
                        <h3 class="item-title">Kulübe Üye Olun</h3>
                        <?php echo Form::open(['route'=>['club_join_store'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>


                        <div class="row gutters-20">


                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                                    <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                    <input type="hidden" name="club_id" value="<?php echo e($club->id); ?>">
                                    <input type="hidden" name="status" value="0">
                                <?php endif; ?>
                            <?php endif; ?>












                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                                    <div class="col-lg-12 form-group">
                                        <button id="gameStart" class="submit-btn" type="submit">Kaydol</button>
                                    </div>

                                <?php else: ?>

                                    <div class="alert alert-info">
                                       Kulübe Kaydolmaz için lütfen giriş yapınız. Giriş yapmak için


                                        <a href="<?php echo e(route('login')); ?>" class="alert-link">
                                            tıklayınız.
                                        </a>


                                    </div>


                                <?php endif; ?>
                            <?php endif; ?>



                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        <?php if(session('alert')): ?>
        swal({
            title:"Başarılı",
            text:"Katılma İsteği Başarılı Bir Şekilde Gönderildi",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('no')): ?>
        swal({
            title:"Hata",
            text:"Katılma İsteği Gönderilemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('nosd')): ?>
        swal({
            title:"Hata",
            text:"Mükerrer Kayıt",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/club_join.blade.php ENDPATH**/ ?>