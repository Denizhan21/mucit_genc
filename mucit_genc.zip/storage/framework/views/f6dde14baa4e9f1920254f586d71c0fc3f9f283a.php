<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                        <div class="block-box post-view">
                            <div class="post-header">
                                <div class="media">
                                    <div class="user-img">

                                        <?php if(Route::has('login')): ?>
                                            <?php if(auth()->guard()->check()): ?>

                                        <?php if(!empty($projects->student->avatar)): ?>
                                            <img src="/<?php echo e($projects->student->avatar); ?>" alt="<?php echo e($projects->student->name); ?>">
                                        <?php else: ?>
                                            <img src="/homepage/media/figure/chat_10.jpg" alt="<?php echo e($projects->student->name); ?>">
                                        <?php endif; ?>

                                            <?php else: ?>
                                                <img src="/homepage/media/figure/chat_10.jpg" alt="gönderen">
                                            <?php endif; ?>
                                            <?php endif; ?>
                                    </div>
                                    <div class="media-body">
                                        <?php if(Route::has('login')): ?>
                                            <?php if(auth()->guard()->check()): ?>
                                        <div class="user-title"><a href="user-timeline.html"><?php echo e($projects->student->name); ?></a></div>
                                            <?php else: ?>
                                                <div class="user-title"><a href="user-timeline.html">Gönderen öğrencinin ismini görebilmek için sisteme giriş yapmanız gerekmektedir</a></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <ul class="entry-meta">
                                            <li class="meta-time">
                                                <?php
                                                date_default_timezone_set('Europe/Istanbul');
                                                $bugunTarihi=date("d-m-Y H:i:s");
                                                $girilentarih=date('d-m-Y H:i:s',  strtotime($projects->created_at));
                                                $date1=date_create($girilentarih);
                                                $date2=date_create($bugunTarihi);
                                                $diff=date_diff($date1,$date2);
                                                echo $diff->format("%s saniye, %i dakika, %H saat, %d gün, %m ay, %Y yıl önce.");
                                                ?>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="post-body">
                                <p><b><?php echo e($projects->name); ?></b></p>
                                <p><?php echo $projects->description; ?></p>
                                <?php if($projects->type=='Fotoğraf'): ?>



                                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">


                                        <div class="carousel-indicators">

                                            <?php $__currentLoopData = json_decode($projects->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($key); ?>" class="<?php echo e($key==0?'active':''); ?>" aria-current="true" aria-label="Slide <?php echo e($key+1); ?>"></button>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>


                                        <div class="carousel-inner">

                                            <?php $__currentLoopData = json_decode($projects->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="carousel-item <?php echo e($key==0?'active':''); ?>">
                                                    <img style="width:710px;height: 400px; " src="/<?php echo e($image); ?>" class="d-block w-100" alt="Gallery">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </div>



                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Previous</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Next</span>
                                        </button>


                                    </div>




                                





                                <?php elseif($projects->type=='Video'): ?>
                                    <?php
                                    $metin  = $projects->content;
                                    $eski   = "view?usp=sharing";
                                    $yeni   = "preview";
                                    $metin = str_replace($eski, $yeni, $metin);
                                    ?>
                                    <iframe src="<?php echo e($metin); ?>" frameborder="0" width="710" height="400"></iframe>
                                <?php elseif($projects->type=='Power Point'): ?>
                                    <?php
                                    $metin  = $projects->content;
                                    $eski   = "view?usp=sharing";
                                    $yeni   = "preview";
                                    $metin = str_replace($eski, $yeni, $metin);
                                    ?>
                                    <iframe src="<?php echo e($metin); ?>" frameborder="0" width="710" height="400"></iframe>
                                <?php endif; ?>










                                <div class="post-meta-wrap">
                                    <div class="post-meta">
                                        <div class="post-reaction">
                                            <div class="reaction-icon">
                                                <?php if(count($reaction_1)!=0): ?>
                                            <img style="width: 24px;" src="/homepage/media/figure/like.svg" alt="Like">
                                                <?php endif; ?>
                                                <?php if(count($reaction_2)!=0): ?>
                                            <img style="width: 24px;" src="/homepage/media/figure/celebrate.svg" alt="Like">
                                                    <?php endif; ?>
                                                <?php if(count($reaction_3)!=0): ?>
                                            <img style="width: 24px;" src="/homepage/media/figure/support.svg" alt="Like">
                                                    <?php endif; ?>
                                                <?php if(count($reaction_4)!=0): ?>
                                            <img style="width: 24px;" src="/homepage/media/figure/love.svg" alt="Like">
                                                    <?php endif; ?>
                                                <?php if(count($reaction_5)!=0): ?>
                                            <img style="width: 24px;" src="/homepage/media/figure/insightful.svg" alt="Like">
                                                    <?php endif; ?>
                                                <?php if(count($reaction_6)!=0): ?>
                                            <img style="width: 24px;" src="/homepage/media/figure/curious.svg" alt="Like">
                                                    <?php endif; ?>








                                            </div>
                                            <div class="meta-text"><?php echo e(count($rating)); ?></div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="post-footer">
                                <ul>  <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                    <li class="post-react">
                                        <a href="#">
                                            <?php if(empty($rating_login)): ?>
                                            <i class="icofont-thumbs-up"></i>
                                            <?php elseif($rating_login->rateable_type==1): ?>
                                            <img style="width: 20px;" src="/homepage/media/figure/like.svg" alt="Like">
                                            <?php elseif($rating_login->rateable_type==2): ?>
                                            <img style="width: 20px;" src="/homepage/media/figure/celebrate.svg" alt="Like">
                                            <?php elseif($rating_login->rateable_type==3): ?>
                                            <img style="width: 20px;" src="/homepage/media/figure/support.svg" alt="Like">
                                            <?php elseif($rating_login->rateable_type==4): ?>
                                            <img style="width: 20px;" src="/homepage/media/figure/love.svg" alt="Like">
                                            <?php elseif($rating_login->rateable_type==5): ?>
                                            <img style="width: 20px;" src="/homepage/media/figure/insightful.svg" alt="Like">
                                            <?php elseif($rating_login->rateable_type==6): ?>
                                            <img style="width: 20px;" src="/homepage/media/figure/curious.svg" alt="Like">
                                            <?php endif; ?>

                                            Emoji Bırak!</a>
                                        <ul class="react-list emojies">

                                         <?php if(!empty($rating_login)): ?>
                                                <?php echo Form::model($rating_login,['route'=>['like_send_update',$rating_login->id],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>

                                                <li><label class="like-button" for="1"><input id="1" type="radio" name="rateable_type" value="1" <?php echo e($rating_login->rateable_type==1?'checked':''); ?>><img src="/homepage/media/figure/like.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="2"><input id="2" type="radio" name="rateable_type" value="2" <?php echo e($rating_login->rateable_type==2?'checked':''); ?>><img src="/homepage/media/figure/celebrate.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="3"><input id="3" type="radio" name="rateable_type" value="3" <?php echo e($rating_login->rateable_type==3?'checked':''); ?>><img src="/homepage/media/figure/support.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="4"><input id="4" type="radio" name="rateable_type" value="4" <?php echo e($rating_login->rateable_type==4?'checked':''); ?>><img src="/homepage/media/figure/love.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="5"><input id="5" type="radio" name="rateable_type" value="5" <?php echo e($rating_login->rateable_type==5?'checked':''); ?>><img src="/homepage/media/figure/insightful.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="6"><input id="6" type="radio" name="rateable_type" value="6" <?php echo e($rating_login->rateable_type==6?'checked':''); ?>><img src="/homepage/media/figure/curious.svg" alt="Like"></label></li>
                                                <li><button class="btn btn-white" type="submit">Gönder</button></li>
                                                <?php echo Form::close(); ?>

                                            <?php else: ?>
                                                <?php echo Form::open(['route'=>['like_send'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>

                                                <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                                <input type="hidden" name="rateable_id" value="<?php echo e($projects->id); ?>">
                                                <input type="hidden" name="rating" value="1">
                                                <li><label class="like-button" for="1"><input id="1" type="radio" name="rateable_type" value="1" ><img src="/homepage/media/figure/like.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="2"><input id="2" type="radio" name="rateable_type" value="2" ><img src="/homepage/media/figure/celebrate.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="3"><input id="3" type="radio" name="rateable_type" value="3" ><img src="/homepage/media/figure/support.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="4"><input id="4" type="radio" name="rateable_type" value="4" ><img src="/homepage/media/figure/love.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="5"><input id="5" type="radio" name="rateable_type" value="5" ><img src="/homepage/media/figure/insightful.svg" alt="Like"></label></li>
                                                <li><label class="like-button" for="6"><input id="6" type="radio" name="rateable_type" value="6" ><img src="/homepage/media/figure/curious.svg" alt="Like"></label></li>
                                                <li><button class="btn btn-white" type="submit">Gönder</button></li>
                                                <?php echo Form::close(); ?>

                                            <?php endif; ?>


                                        </ul>
                                    </li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <li><i class="icofont-comment"></i><?php echo e(count($comment)); ?> Yorum  </li>
                                   
                                </ul>
                            </div>
                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                            <?php if(\Illuminate\Support\Facades\Auth::user()->comment_authority==1): ?>
                                <?php echo Form::open(['route'=>['comment_send'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>



                                        <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">


                                <input type="hidden" name="project_id" value="<?php echo e($projects->id); ?>">
                                <input type="hidden" name="status" value="">

                                <div class="col-lg-12 form-group">
                                    <textarea name="content" class="form-control textarea" placeholder="Yorumunuzu Gönderebilirsiniz . . ." cols="30" rows="7"></textarea>
                                </div>

                                <div class="col-lg-12 form-group">
                                    <button id="gameStart" class="submit-btn" type="submit">Gönder</button>
                                </div>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>

                            <div class="single-product-info">
                                <div class="tab-content">
                                    <div class="tab-pane fade active show" id="reviews" role="tabpanel">
                                        <div class="product-review">
                                            <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="media">
                                                <div class="item-img">
                                                    <img src="/homepage/media/figure/author_5.jpg" alt="blog">
                                                </div>
                                                <div class="media-body">
                                                    <div class="item-date">
                                                       
                                                        <?php
                                                            setlocale(LC_TIME, "turkish");
                                                            setlocale(LC_ALL,'turkish');
                                                            echo iconv('latin5','utf-8',strftime('%d %B %Y %A',strtotime($comments->created_at)));
                                                        ?>
                                                    </div>
                                                    <div class="author-name">
                                                        <h5 class="item-title"><?php echo e($comments->user->name); ?></h5>

                                                    </div>
                                                    <p><?php echo $comments->content; ?></p>
                                                </div>
                                            </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>




                        </div>

                </div>



                <div class="col-lg-4 widget-block widget-break-lg">
                    <div class="widget widget-memebers">
                        <div class="widget-heading">
                            <h3 class="widget-title">Öğretmen Yorumu</h3>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="newest-member" role="tabpanel">
                                <div class="members-list">

                                    <?php $__currentLoopData = $teacher_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media">
                                        <div class="item-img">
                                            <a href="#">
                                                <img src="/homepage/media/figure/chat_1.jpg" alt="Chat">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <h4 class="item-title"><a href="#"><?php echo e($teacher_comment->teachers->name); ?></a></h4>
                                            <p style="word-wrap: break-word;width: 250px;">
                                                <?php echo $teacher_comment->content; ?>

                                            </p>

                                        </div>

                                    </div>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                    <?php if(\Illuminate\Support\Facades\Auth::user()->authority=='teacher'): ?>

                                        <?php
                                        $aaa = \App\Teacher_comment::where('project_id','=',$projects->id)->where('user_id','=',\Illuminate\Support\Facades\Auth::id())->first();
                                        ?>

                                                <?php if(empty($aaa)): ?>
                                                <?php echo Form::open(['route'=>['teacher_comment'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>


                                                <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>">
                                                <input type="hidden" name="project_id" value="<?php echo e($projects->id); ?>">
                                                <div class="col-lg-12 form-group">

                                        <textarea name="content" cols="30" rows="10"></textarea>

                                        </div>
                                        <button class="btn btn-dark">Yorum yap</button>
                                        <?php echo Form::close(); ?>

                                                    <?php else: ?>
                                                        <?php echo Form::model($aaa,['route'=>['teacher_comment_update',$aaa->id],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>


                                                        <div class="col-lg-12 form-group">

                                                            <textarea name="content" cols="30" rows="10"><?php echo e($aaa->content); ?></textarea>

                                                        </div>
                                                        <button class="btn btn-dark">Yorum yap</button>
                                                        <?php echo Form::close(); ?>


                                                    <?php endif; ?>



                                    <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                </div>


                            </div>
                        </div>
                    </div>

                    <div class="widget widget-memebers">
                        <div class="widget-heading">
                            <h3 class="widget-title">Gönderen Öğrenci Yorumu</h3>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="newest-member" role="tabpanel">
                                <div class="members-list">
                                    <p><?php echo $projects->student_comment; ?></p>
                                    <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                    <?php if($projects->user_id==\Illuminate\Support\Facades\Auth::user()->id): ?>
                                    <?php echo Form::model($projects,['route'=>['student_comment',$projects->id],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>

                                        <div class="col-lg-12 form-group">
                                    <textarea name="student_comment" cols="30" rows="10"><?php echo e($projects->student_comment); ?></textarea>
                                        </div>
                                    <button class="btn btn-dark">Yorum yap</button>
                                    <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script>
        <?php if(session('alert')): ?>

        swal({
            title:"Başarılı",
            text:"Yorumunuz gönderilmiş olup onaylandıktan sonra yayınlanacaktır.",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('no')): ?>
        swal({
            title:"Hata",
            text:"Yorum gönderilemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
    <script>
        <?php if(session('alert')): ?>

        swal({
            title:"Başarılı",
            text:"Yorumunuz başarıyla yapılmıştır.",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('no')): ?>
        swal({
            title:"Hata",
            text:"Yorum gönderilemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
    <script>
        <?php if(session('alert')): ?>

        swal({
            title:"Başarılı",
            text:"Yorumunuz başarıyla yapılmıştır.",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('no')): ?>
        swal({
            title:"Hata",
            text:"Yorum gönderilemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
    <script>
        <?php if(session('alertsd')): ?>

        swal({
            title:"Başarılı",
            text:"Emoji Gönderildi.",
            type: "success",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
        <?php if(session('nosd')): ?>
        swal({
            title:"Hata",
            text:"Emoji gönderilemedi",
            type: "warning",
            timer:2000,
            showConfirmButton: false
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/projects_details.blade.php ENDPATH**/ ?>