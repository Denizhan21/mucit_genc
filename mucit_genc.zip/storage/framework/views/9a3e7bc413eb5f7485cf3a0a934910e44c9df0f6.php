<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
            <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)">Mucit Genç</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Yönetim Paneli</a>
            </li>
        </ul>
    </div>
    &copy; 2021 Denizhan Yazılım. Tüm Hakları Sakldıır.
</footer>
<?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/admin/footer.blade.php ENDPATH**/ ?>