<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <div class="container">

            <div class="row gutters-20 zoom-gallery">


                <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$clubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="user-group-photo">
                        <p align="center"><?php echo e($clubs->name); ?></p>
                        <a href="/clubs/<?php echo e($clubs->id); ?>">
                            <img style="width: 280px;height: 230px;" src="/<?php echo e($clubs->logo); ?>" alt="Gallery">
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/club_view.blade.php ENDPATH**/ ?>