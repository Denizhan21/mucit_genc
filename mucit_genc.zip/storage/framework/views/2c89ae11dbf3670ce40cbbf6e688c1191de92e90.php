<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container">
            <div class="block-box user-single-blog">
                <div class="blog-content-wrap">
                    <div class="blog-comment-form">
                        <h3 class="item-title">Projenizi Gönderin</h3>
                        <?php echo Form::open(['route'=>['project_store'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>


                        <div class="row gutters-20">


                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                            <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                    <input type="hidden" name="status" value="0">

                                <?php endif; ?>
                            <?php endif; ?>



                            <?php
                                $talepgrup = [
                                    'photo'=>'Fotoğraf',
                                    'power_point'=>'Power Point',
                                    'video'=>'Video',
                                    ];
                            ?>

                            <div class="col-lg-12">


                                <div id="type" class="alert alert-danger" role="alert" style="display: none">
                                    Lütfen dosya türünüzü seçiniz.
                                </div>


                                <label><b>Göndericeğiniz Dosya Türünü Seçiniz:</b></label>

                                <?php $__currentLoopData = $talepgrup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$alan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <input type="radio" name="type" id="<?php echo e($key); ?>" value="<?php echo e($alan); ?>" required class="type_type" onclick="return tipOther()"/>
                                    <label for="<?php echo e($key); ?>"><?php echo e($alan); ?></label>&nbsp;&nbsp;&nbsp;

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>

                            <div class="col-lg-12 form-group">

                                <div id="name_name" class="alert alert-danger" role="alert" style="display: none">
                                    Lütfen Projenizin adını giriniz.
                                </div>

                                <label>Projenizin Adını Giriniz:</label>
                                <input id="name_name_name" name="name" type="text" class="form-control name_name" placeholder="Projenizin Adını Giriniz">
                            </div>

                            <div class="col-lg-12 form-group" id="video_area" style="display: none">

                                <div class="alert alert-warning">
                                    <strong>Dikkat!</strong> Drive linkinizi belirtilen şekilde yükeleyiniz. Anlatım videosu için

                                    <div class="video-btn">
                                        <a href="https://drive.google.com/file/d/1CV4GWlHQnWj-QGvsmm3hy5wTL4Azs0EE/preview" class="popup-youtube play-icon alert-link">
                                            tıklayınız.
                                        </a>
                                    </div>

                                </div>

                                <label>Drive Linkinizi Giriniz:</label>
                                <input name="content" type="text" class="form-control" placeholder="Video için Drive Linkinizi Giriniz">

                                <div class="col-lg-12 form-group" >
                                    <label>Proje Kapak Fotoğrafınızı Seçiniz:</label>
                                    <input id="name" type="file" class="form-control"  name="photo">
                                </div>

                            </div>

                            <div class="col-lg-12 form-group" id="power_point_area" style="display: none">

                                <div class="alert alert-warning">
                                    <strong>Dikkat!</strong> Drive linkinizi belirtilen şekilde yükeleyiniz. Anlatım videosu için

                                    <div class="video-btn">
                                        <a href="https://drive.google.com/file/d/1CV4GWlHQnWj-QGvsmm3hy5wTL4Azs0EE/preview" class="popup-youtube play-icon alert-link">
                                            tıklayınız.
                                        </a>
                                    </div>

                                </div>

                                <label>Drive Linkinizi Giriniz:</label>
                                <input name="content" type="text" class="form-control" placeholder="Power Point için Drive Linkinizi Giriniz">

                                <div class="col-lg-12 form-group" >
                                    <label>Proje Kapak Fotoğrafınızı Seçiniz:</label>
                                    <input id="name" type="file" class="form-control"  name="photo">
                                </div>

                            </div>

                            <div class="col-lg-12 form-group" id="photo_area" style="display: none">
                                    <label>Fotoğraflarınızı Seçiniz:</label>
                                    <input id="name" type="file" class="form-control"  name="content[]"  multiple>
                            </div>

                            <div class="col-lg-12 form-group">
                                <label>Projenizi Göndddermek İstediğiniz Kulübü Seçiniz:</label>
                                <select class="form-control" name="club_id">
                                    <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($clubs->id); ?>"><?php echo e($clubs->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $clubs_club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clubs_c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $confirmation_club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($confirmation->club_id == $clubs_c->id): ?>
                                            <option value="<?php echo e($confirmation->clubs->id); ?>"><?php echo e($confirmation->clubs->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-lg-12 form-group">
                                <textarea name="description" class="form-control textarea" placeholder="Projenizin detaylarını giriniz . . ." cols="30" rows="7"></textarea>
                            </div>


                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>

                            <div class="col-lg-12 form-group">
                                <button id="gameStart" class="submit-btn" type="submit">Gönder</button>
                            </div>

                                <?php else: ?>

                                        <div class="alert alert-info">
                                             Projenizi göndermek için lütfen giriş yapınız. Giriş yapmak için


                                                <a href="<?php echo e(route('login')); ?>" class="alert-link">
                                                    tıklayınız.
                                                </a>


                                        </div>


                                <?php endif; ?>
                            <?php endif; ?>



                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        <?php $__currentLoopData = $talepgrup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$alan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        document.getElementById('<?php echo e($key); ?>').addEventListener('change', function () {
            if (document.getElementById('<?php echo e($key); ?>').checked) {
                document.getElementById('<?php echo e($key); ?>_area').style.display = 'block';
            }
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>

    <script>
        function tipOther() {

            document.getElementById('video_area').style.display = 'none';
            document.getElementById('power_point_area').style.display = 'none';
            document.getElementById('photo_area').style.display = 'none';
        }
    </script>


    <script type="text/javascript">
        $(document).ready(function () {
            $('#gameStart').click(function() {
                checked = $("input[class=type_type]:checked").length;
                if(!checked) {
                    document.getElementById('type').style.display = 'block';
                    return false
                }else {
                    document.getElementById('type').style.display = 'none';
                }
            });
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#gameStart').click(function() {
                if(document.getElementById("name_name_name").value=="") {
                    document.getElementById('name_name').style.display = 'block';
                    return false
                }else {
                    document.getElementById('name_name').style.display = 'none';
                }
            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/project_send.blade.php ENDPATH**/ ?>