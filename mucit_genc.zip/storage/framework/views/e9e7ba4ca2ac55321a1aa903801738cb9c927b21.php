<?php $__env->startSection('content'); ?>
    <div class="page-content">


        <div class="container">

            <div class="newsfeed-banner">
                <div class="media">

                    <div class="media-body">
                        <h3 class="item-title"><?php echo e($clubs->name); ?></h3>
                       
                    </div>
                </div>
                <ul class="animation-img">
                    <li data-sal="slide-down" data-sal-duration="800" data-sal-delay="400"><img src="/homepage/media/banner/shape_7.png" alt="shape"></li>

                    <?php if(!empty($clubs->logo)): ?>
                    <li data-sal="slide-up" data-sal-duration="500"><img style="width: 525px;height: 179px;" src="/<?php echo e($clubs->logo); ?>" alt="shape"></li>
                    <?php endif; ?>

                </ul>
            </div>


            <div class="newsfeed-search">
                <ul class="member-list">

                    <li class="active-member">
                        <a href="#">
                                <span class="member-icon">
                                    <i class="icofont-users"></i>
                                </span>
                            <span class="member-text">
                                    Toplam Üye:
                                </span>
                            <span class="member-count"><?php echo e(count($clubs_users)); ?></span>
                        </a>
                    </li>

                    <li class="active-member">
                        <a href="#">
                                <span class="member-icon">
                                    <i class="icofont-notepad"></i>
                                </span>
                            <span class="member-text">
                                    Toplam Proje:
                                </span>
                            <span class="member-count"><?php echo e(count($clubs_projects)); ?></span>
                        </a>
                    </li>

                </ul>
                <?php if($clubs->status=='1'): ?>
                <ul class="search-list">

                    <li class="search-input">
                        <div class="widget ">
                        <a href="#" class="item-btn">
                            <span class="btn-text">Kayıt Ol</span>
                            <span class="btn-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="21px" height="10px">
                                        <path fill-rule="evenodd" d="M16.671,9.998 L12.997,9.998 L16.462,6.000 L5.000,6.000 L5.000,4.000 L16.462,4.000 L12.997,0.002 L16.671,0.002 L21.003,5.000 L16.671,9.998 ZM17.000,5.379 L17.328,5.000 L17.000,4.621 L17.000,5.379 ZM-0.000,4.000 L3.000,4.000 L3.000,6.000 L-0.000,6.000 L-0.000,4.000 Z" />
                                    </svg>
                                </span>
                        </a>
                        </div>

                    </li>
                </ul>
                <?php endif; ?>
            </div>




            <div class="row">




                <div class="col-lg-8">
                    <div  id="newest-member" role="tabpanel" class="block-box user-about">
                        <div class="widget-heading">
                            <h3 class="widget-title">Kulüp Detayları</h3>
                        </div>
                        <ul class="user-info">
                            <li>
                                <label>Kulüp Konusu</label>
                                <p><?php echo e($clubs->subject); ?></p>
                            </li>
                            <li>
                                <label>Kulüp Açıklaması</label>
                                <p><?php echo $clubs->description; ?></p>
                            </li>
                        </ul>
                        <hr>
                        <div class="widget-heading">
                            <h4><small>Kulüp Tanıtımı</small></h4>
                        </div>
                        <?php
                        $metin  = $clubs->text;
                        $eski   = "view?usp=sharing";
                        $yeni   = "preview";
                        $metin = str_replace($eski, $yeni, $metin);
                        ?>
                        <iframe src="<?php echo e($metin); ?>" frameborder="0" width="710" height="400"></iframe>
                    </div>
















                    <?php $__currentLoopData = $clubs_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$club_projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="block-box post-view">
                        <div class="post-header">
                            <div class="media">
                                <div class="user-img">
                                    <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                    <?php if(!empty($club_projects->student->avatar)): ?>
                                        <img src="/<?php echo e($club_projects->student->avatar); ?>" alt="<?php echo e($club_projects->student->name); ?>">
                                    <?php else: ?>
                                    <img src="/homepage/media/figure/chat_10.jpg" alt="<?php echo e($club_projects->student->name); ?>">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="/homepage/media/figure/chat_10.jpg" alt="<?php echo e($club_projects->student->name); ?>">
                                        <?php endif; ?>
                                        <?php endif; ?>


                                </div>
                                <div class="media-body">
                                    <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                    <div class="user-title"><a href="user-timeline.html"><?php echo e($club_projects->student->name); ?></a></div>
                                        <?php else: ?>
                                            <div class="user-title"><a href="user-timeline.html">Gönderen öğrencinin ismini görebilmek için sisteme giriş yapmanız gerekmektedir</a></div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <ul class="entry-meta">
                                        <li class="meta-time">
                                         

                                            <?php
                                                setlocale(LC_TIME, "turkish");
                                                setlocale(LC_ALL,'turkish');
                                                echo iconv('latin5','utf-8',strftime('%d %B %Y %A',strtotime($club_projects->created_at)));
                                            ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="post-body">
                            <p><b><?php echo e($club_projects->name); ?></b></p>
                            <p><?php echo e($club_projects->description); ?></p>




                            <?php if($club_projects->type=='Fotoğraf'): ?>


                                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">


                                    <div class="carousel-indicators">

                                        <?php $__currentLoopData = json_decode($club_projects->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($key); ?>" class="<?php echo e($key==0?'active':''); ?>" aria-current="true" aria-label="Slide <?php echo e($key+1); ?>"></button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>


                                    <div class="carousel-inner">

                                        <?php $__currentLoopData = json_decode($club_projects->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php echo e($key==0?'active':''); ?>">
                                                <img style="width:710px;height: 400px; " src="/<?php echo e($image); ?>" class="d-block w-100" alt="Gallery">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </div>



                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>


                                </div>



                

                            <?php elseif($club_projects->type=='Video'): ?>
                                <img style="width: 710px;height: 400px" src="/<?php echo e($club_projects->photo); ?>" alt="Groups">
                                <?php
                                $metin  = $club_projects->content;
                                $eski   = "view?usp=sharing";
                                $yeni   = "preview";
                                $metin = str_replace($eski, $yeni, $metin);
                                ?>
                                <iframe src="<?php echo e($metin); ?>" frameborder="0" width="710" height="400"></iframe>
                            <?php elseif($club_projects->type=='Power Point'): ?>
                                <img style="width: 710px;height: 400px" src="/<?php echo e($club_projects->photo); ?>" alt="Groups">
                                <?php
                                $metin  = $club_projects->content;
                                $eski   = "view?usp=sharing";
                                $yeni   = "preview";
                                $metin = str_replace($eski, $yeni, $metin);
                                ?>
                                <iframe src="<?php echo e($metin); ?>" frameborder="0" width="710" height="400"></iframe>
                            <?php endif; ?>










                            <div class="post-meta-wrap">
                                <div class="post-meta">
                                    <div class="post-reaction">
                                        <div class="reaction-icon">
                                            <?php
                                                $reaction_1 = count(\App\Rating::where('rateable_id','=',$club_projects->id)->where('rateable_type','=',1)->get())
                                            ?>
                                            <?php if(!empty($reaction_1)): ?>
                                                <img style="width: 24px;" src="/homepage/media/figure/like.svg" alt="Like">
                                            <?php endif; ?>
                                            <?php
                                                $reaction_2 = count(\App\Rating::where('rateable_id','=',$club_projects->id)->where('rateable_type','=',2)->get())
                                            ?>
                                            <?php if(!empty($reaction_2)): ?>
                                                <img style="width: 24px;" src="/homepage/media/figure/celebrate.svg" alt="Like">
                                            <?php endif; ?>
                                            <?php
                                                $reaction_3 = count(\App\Rating::where('rateable_id','=',$club_projects->id)->where('rateable_type','=',3)->get())
                                            ?>
                                            <?php if(!empty($reaction_3)): ?>
                                                <img style="width: 24px;" src="/homepage/media/figure/support.svg" alt="Like">
                                            <?php endif; ?>
                                            <?php
                                                $reaction_4 = count(\App\Rating::where('rateable_id','=',$club_projects->id)->where('rateable_type','=',4)->get())
                                            ?>
                                            <?php if(!empty($reaction_4)): ?>
                                                <img style="width: 24px;" src="/homepage/media/figure/love.svg" alt="Like">
                                            <?php endif; ?>
                                            <?php
                                                $reaction_5 = count(\App\Rating::where('rateable_id','=',$club_projects->id)->where('rateable_type','=',5)->get())
                                            ?>
                                            <?php if(!empty($reaction_5)): ?>
                                                <img style="width: 24px;" src="/homepage/media/figure/insightful.svg" alt="Like">
                                            <?php endif; ?>
                                            <?php
                                                $reaction_6 = count(\App\Rating::where('rateable_id','=',$club_projects->id)->where('rateable_type','=',6)->get())
                                            ?>
                                            <?php if(!empty($reaction_6)): ?>
                                                <img style="width: 24px;" src="/homepage/media/figure/curious.svg" alt="Like">
                                            <?php endif; ?>

                                        </div>
                                        <div class="meta-text"><?php echo e(count($rating = \App\Rating::where('rateable_id','=',$club_projects->id)->get())); ?></div>
                                    </div>
                                </div>
                                <?php
                                    $comment = \App\Comment::where('project_id','=',$club_projects->id)->where('status','=','1')->get();
                                ?>
                                <div class="post-meta">
                                    <div class="meta-text"><?php echo e(count($comment)); ?> Yorum  </div>
                                </div>
                            </div>
                        </div>
                        <div class="post-footer">
                            <ul>
                                <?php if(Route::has('login')): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <li class="post-react">
                                            <?php
                                                $login = \Illuminate\Support\Facades\Auth::id();

                                            $rating_login = \App\Rating::where('rateable_id','=',$club_projects->id)->where('user_id','=',$login)->first();
                                            ?>
                                            <a href="#">
                                                <?php if(empty($rating_login)): ?>
                                                    <i class="icofont-thumbs-up"></i>
                                                <?php elseif($rating_login->rateable_type==1): ?>
                                                    <img style="width: 20px;" src="/homepage/media/figure/like.svg" alt="Like">
                                                <?php elseif($rating_login->rateable_type==2): ?>
                                                    <img style="width: 20px;" src="/homepage/media/figure/celebrate.svg" alt="Like">
                                                <?php elseif($rating_login->rateable_type==3): ?>
                                                    <img style="width: 20px;" src="/homepage/media/figure/support.svg" alt="Like">
                                                <?php elseif($rating_login->rateable_type==4): ?>
                                                    <img style="width: 20px;" src="/homepage/media/figure/love.svg" alt="Like">
                                                <?php elseif($rating_login->rateable_type==5): ?>
                                                    <img style="width: 20px;" src="/homepage/media/figure/insightful.svg" alt="Like">
                                                <?php elseif($rating_login->rateable_type==6): ?>
                                                    <img style="width: 20px;" src="/homepage/media/figure/curious.svg" alt="Like">
                                                <?php endif; ?>
                                                Emoji Bırak!</a>
                                            <ul class="react-list">

                                                <?php if(!empty($rating_login)): ?>
                                                    <?php echo Form::model($rating_login,['route'=>['like_send_update',$rating_login->id],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>

                                                    <li><label class="like-button" for="<?php echo e($key+7); ?>"><input id="<?php echo e($key+7); ?>" type="radio" name="rateable_type" value="1" <?php echo e($rating_login->rateable_type==1?'checked':''); ?>><img src="/homepage/media/figure/like.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+14); ?>"><input id="<?php echo e($key+14); ?>" type="radio" name="rateable_type" value="2" <?php echo e($rating_login->rateable_type==2?'checked':''); ?>><img src="/homepage/media/figure/celebrate.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+21); ?>"><input id="<?php echo e($key+21); ?>" type="radio" name="rateable_type" value="3" <?php echo e($rating_login->rateable_type==3?'checked':''); ?>><img src="/homepage/media/figure/support.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+28); ?>"><input id="<?php echo e($key+28); ?>" type="radio" name="rateable_type" value="4" <?php echo e($rating_login->rateable_type==4?'checked':''); ?>><img src="/homepage/media/figure/love.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+35); ?>"><input id="<?php echo e($key+35); ?>" type="radio" name="rateable_type" value="5" <?php echo e($rating_login->rateable_type==5?'checked':''); ?>><img src="/homepage/media/figure/insightful.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+42); ?>"><input id="<?php echo e($key+42); ?>" type="radio" name="rateable_type" value="6" <?php echo e($rating_login->rateable_type==6?'checked':''); ?>><img src="/homepage/media/figure/curious.svg" alt="Like"></label></li>
                                                    <li><button class="btn btn-white" type="submit">Gönder</button></li>
                                                    <?php echo Form::close(); ?>

                                                <?php else: ?>
                                                    <?php echo Form::open(['route'=>['like_send'],'method'=>'POST','files'=>'true','class'=>'form-horizontal']); ?>

                                                    <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                                    <input type="hidden" name="rateable_id" value="<?php echo e($club_projects->id); ?>">
                                                    <input type="hidden" name="rating" value="1">
                                                    <li><label class="like-button" for="<?php echo e($key+7); ?>"><input id="<?php echo e($key+7); ?>" type="radio" name="rateable_type" value="1" ><img src="/homepage/media/figure/like.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+14); ?>"><input id="<?php echo e($key+14); ?>" type="radio" name="rateable_type" value="2" ><img src="/homepage/media/figure/celebrate.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+24); ?>"><input id="<?php echo e($key+21); ?>" type="radio" name="rateable_type" value="3" ><img src="/homepage/media/figure/support.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+28); ?>"><input id="<?php echo e($key+28); ?>" type="radio" name="rateable_type" value="4" ><img src="/homepage/media/figure/love.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+35); ?>"><input id="<?php echo e($key+35); ?>" type="radio" name="rateable_type" value="5" ><img src="/homepage/media/figure/insightful.svg" alt="Like"></label></li>
                                                    <li><label class="like-button" for="<?php echo e($key+42); ?>"><input id="<?php echo e($key+42); ?>" type="radio" name="rateable_type" value="6" ><img src="/homepage/media/figure/curious.svg" alt="Like"></label></li>
                                                    <li><button class="btn btn-white" type="submit">Gönder</button></li>
                                                    <?php echo Form::close(); ?>

                                                <?php endif; ?>


                                            </ul>
                                        </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                    <li class="post-react">
                                        <a href="/projects/<?php echo e($club_projects->id); ?>"><i class="icofont-arrow-right"></i>Projeye Git</a>
                                    </li>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </div>


                <div class="col-lg-4 widget-block widget-break-lg">


                    <div class="widget widget-user-about">
                        <div class="widget-heading">
                            <h3 class="widget-title">Görevli Öğretmen</h3>

                        </div>
                        <div class="user-info">
                            <p><?php echo e($clubs->teachers->name); ?></p>
                            <a href="/club_contact/<?php echo e($clubs->id); ?>" class="btn btn-dark">Öğretmene Sor</a>
                        </div>
                    </div>

                    <div class="widget widget-memebers">
                        <div class="widget-heading">
                            <h3 class="widget-title">Öğrenciler</h3>

                        </div>

                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="newest-member" role="tabpanel">
                                <div class="members-list">
                                    <?php $__currentLoopData = $clubs_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media">
                                        <div class="item-img">
                                            <a href="#">
                                                <?php if(!empty($student->student->avatar)): ?>
                                                    <img src="/<?php echo e($student->student->avatar); ?>" alt="Chat">
                                                <?php else: ?>
                                                <img src="/homepage/media/figure/chat_1.jpg" alt="Chat">

                                                    <?php endif; ?>

                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <h4 class="item-title"><a href="#"><?php echo e($student->student->name); ?></a></h4>

                                        </div>
                                    </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>


                    </div>

                    <div class="widget widget-memebers">
                        <div class="widget-heading">
                            <h3 class="widget-title">Projeler</h3>

                        </div>



                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="newest-member" role="tabpanel">
                                <div class="members-list">

                                    <?php $__currentLoopData = $clubs_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$club_projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="media">
                                            <div class="item-img">
                                                <a href="#">

                                                    <img src="/homepage/media/figure/chat_1.jpg" alt="Chat">


                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="item-title"><a href="#"><?php echo e($club_projects->name); ?></a></h4>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

            </div>


        </div>




    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('homepage.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mucit_genc\resources\views/homepage/clubs_details.blade.php ENDPATH**/ ?>